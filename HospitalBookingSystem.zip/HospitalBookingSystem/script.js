// Sample doctor data
const doctors = [
    { id: 1, name: 'Dr. Roshan Bhujel', specialization: 'Cardiologist' },
    { id: 2, name: 'Dr. John Doe', specialization: 'Dermatologist' },
    { id: 3, name: 'Dr. Emily White', specialization: 'Pediatrician' }
];

// Redirect to Admin Login Page
function redirectToLogin() {
    window.location.href = "admin_login.html";
}

// Check if admin is logged in before accessing dashboard
function checkAdminLogin() {
    const isAdminLoggedIn = sessionStorage.getItem("adminLoggedIn");
    if (!isAdminLoggedIn) {
        alert("Access denied! Please log in as Admin.");
        window.location.href = "admin_login.html";
    }
}

// Logout Admin
function logoutAdmin() {
    sessionStorage.removeItem("adminLoggedIn");
    window.location.href = "admin_login.html";
}

// Admin Login Authentication
const adminLoginForm = document.getElementById("adminLoginForm");
if (adminLoginForm) {
    adminLoginForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const adminId = document.getElementById("adminId").value;
        const adminPassword = document.getElementById("adminPassword").value;
        const loginError = document.getElementById("loginError");

        // Set default credentials
        if (adminId === "admin" && adminPassword === "1234") {
            sessionStorage.setItem("adminLoggedIn", true);
            window.location.href = "admin_dashboard.html";
        } else {
            loginError.textContent = "Invalid Admin ID or Password!";
        }
    });
}

// Load doctors into the dropdown
function loadDoctors() {
    const doctorSelect = document.getElementById('doctorSelect');
    if (doctorSelect) {
        doctors.forEach(doctor => {
            const option = document.createElement('option');
            option.value = doctor.name;
            option.textContent = `${doctor.name} - ${doctor.specialization}`;
            doctorSelect.appendChild(option);
        });
    }
}

// Load appointments from local storage and update UI
function loadAppointments() {
    const appointments = JSON.parse(localStorage.getItem('appointments')) || [];
    const userAppointmentList = document.getElementById('appointmentList');
    const adminAppointmentList = document.getElementById('appointment-list');
    const notificationCount = document.getElementById('notification-count');

    if (notificationCount) {
        notificationCount.textContent = appointments.length;
    }

    // Display appointments for the user (Only allow canceling)
    if (userAppointmentList) {
        userAppointmentList.innerHTML = '';
        appointments.forEach((appointment, index) => {
            const div = document.createElement('div');
            div.className = 'appointment-item';
            div.innerHTML = `
                <span>${appointment.patientName} has an appointment with ${appointment.doctorName} on ${appointment.date} at ${appointment.time} - <b>${appointment.status || 'Pending'}</b></span>
                <button class="cancel-btn" onclick="cancelAppointment(${index})">Cancel</button>
            `;
            userAppointmentList.appendChild(div);
        });
    }

    // Display appointments for the admin (Full control)
    if (adminAppointmentList) {
        adminAppointmentList.innerHTML = '';

        if (appointments.length === 0) {
            adminAppointmentList.innerHTML = "<tr><td colspan='6' style='text-align:center;'>No appointments found</td></tr>";
        } else {
            appointments.forEach((appointment, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${appointment.patientName}</td>
                    <td>${appointment.doctorName}</td>
                    <td>${appointment.date}</td>
                    <td>${appointment.time}</td>
                    <td><span id="status-${index}">${appointment.status || 'Pending'}</span></td>
                    <td>
                        <button class="confirm-btn" onclick="updateStatus(${index}, 'Confirmed')">Confirm</button>
                        <button class="reschedule-btn" onclick="updateStatus(${index}, 'Rescheduled')">Reschedule</button>
                        <button class="cancel-btn" onclick="cancelAppointment(${index})">Cancel</button>
                    </td>
                `;
                adminAppointmentList.appendChild(row);
            });
        }
    }
}

// Handle form submission (User Booking)
const appointmentForm = document.getElementById('appointmentForm');
if (appointmentForm) {
    appointmentForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const patientName = document.getElementById('patientName').value;
        const doctorName = document.getElementById('doctorSelect').value;
        const date = document.getElementById('appointmentDate').value;
        const time = document.getElementById('appointmentTime').value;

        const newAppointment = { patientName, doctorName, date, time, status: 'Pending' };
        let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
        appointments.push(newAppointment);
        localStorage.setItem('appointments', JSON.stringify(appointments));

        loadAppointments();
        appointmentForm.reset();
    });
}

// Allow only users to cancel their appointments
function cancelAppointment(index) {
    let appointments = JSON.parse(localStorage.getItem('appointments')) || [];

    if (!window.location.href.includes('admin_dashboard.html')) {
        // Ensure only the user can cancel their own appointment
        const confirmation = confirm("Are you sure you want to cancel this appointment?");
        if (confirmation) {
            appointments.splice(index, 1);
            localStorage.setItem('appointments', JSON.stringify(appointments));
            loadAppointments();
        }
    } else {
        // Admin can also cancel any appointment
        appointments.splice(index, 1);
        localStorage.setItem('appointments', JSON.stringify(appointments));
        loadAppointments();
    }
}

// Update appointment status in Admin Dashboard
function updateStatus(index, status) {
    if (!window.location.href.includes('admin_dashboard.html')) {
        alert("Only admin can manage appointments!");
        return;
    }

    let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
    appointments[index].status = status;
    localStorage.setItem('appointments', JSON.stringify(appointments));
    document.getElementById(`status-${index}`).textContent = status;
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadDoctors();
    loadAppointments();
});
